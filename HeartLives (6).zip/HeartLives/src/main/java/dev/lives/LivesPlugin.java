package dev.lives;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TranslatableComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerAdvancementDoneEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class LivesPlugin extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    /** The 28 inner slots of a 6-row menu (4 rows of 7). */
    private static final int[] CONTENT_SLOTS = new int[28];

    static {
        int index = 0;
        for (int row = 1; row <= 4; row++) {
            for (int col = 1; col <= 7; col++) {
                CONTENT_SLOTS[index++] = row * 9 + col;
            }
        }
    }

    private enum QuestType { KILL, BREAK, FISH, PLAYTIME, ADVANCEMENT, HUNT, SURVIVE, OBTAIN }

    private record Quest(String id, Component name, Material icon, List<String> description,
                         QuestType type, Set<String> targets, int amount,
                         int lives, int bonusHearts, List<ItemStack> items,
                         int timeLimit, int punishLives, int punishHearts) {
        boolean hasPunishment() {
            return punishLives > 0 || punishHearts > 0;
        }
    }

    /** Values collected while an admin creates a quest in chat. */
    private static final class Draft {
        String id;
        String name;
        QuestType type;
        List<String> targets = new ArrayList<>();
        int amount = 1;
        int lives;
        int bonusHearts;
        List<String> items = new ArrayList<>();
        Material icon = Material.PAPER;
        int timeLimit;
        int punishLives;
        int punishHearts;
    }

    /** Holder used to recognise the revive menu. */
    private static final class ReviveMenu implements InventoryHolder {
        private final Inventory inventory;

        ReviveMenu(Component title) {
            this.inventory = Bukkit.createInventory(this, 54, title);
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    /** Holder for the player quest menu and the admin quest manager (both paged). */
    private static final class PagedMenu implements InventoryHolder {
        private final Inventory inventory;
        private final int page;
        private final boolean admin;

        PagedMenu(Component title, int page, boolean admin) {
            this.page = page;
            this.admin = admin;
            this.inventory = Bukkit.createInventory(this, 54, title);
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final Map<String, Quest> quests = new LinkedHashMap<>();
    private final Map<UUID, Consumer<String>> prompts = new ConcurrentHashMap<>();
    private final Set<UUID> packLoaded = ConcurrentHashMap.newKeySet();
    private final Set<UUID> textureOverride = ConcurrentHashMap.newKeySet(); // admin testing switch
    private static final UUID PACK_ID = UUID.nameUUIDFromBytes("HeartLives-menu-pack".getBytes());

    private File dataFile;
    private YamlConfiguration data;
    private boolean dirty;

    private File questsFile;
    private YamlConfiguration questDefs;

    private NamespacedKey reviveKey;
    private NamespacedKey lifeKey;
    private NamespacedKey targetKey;
    private NamespacedKey questKey;
    private NamespacedKey navKey;

    private int startingLives;
    private int maxLives;
    private int reviveLives;
    private int maxBonusHearts;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        dataFile = new File(getDataFolder(), "data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        questsFile = new File(getDataFolder(), "quests.yml");
        questDefs = YamlConfiguration.loadConfiguration(questsFile);

        reviveKey = new NamespacedKey(this, "revive_item");
        lifeKey = new NamespacedKey(this, "life_item");
        targetKey = new NamespacedKey(this, "revive_target");
        questKey = new NamespacedKey(this, "quest_id");
        navKey = new NamespacedKey(this, "menu_nav");

        loadQuests();
        registerRecipe();
        getServer().getPluginManager().registerEvents(this, this);

        for (String name : List.of("lives", "withdraw", "quests", "questadmin")) {
            PluginCommand command = Objects.requireNonNull(getCommand(name));
            command.setExecutor(this);
            command.setTabCompleter(this);
        }

        // Quest progress is saved every 30 seconds instead of on every block broken.
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (dirty) {
                save();
            }
        }, 600L, 600L);

        // Playtime quests: +1 minute for everyone online, every minute.
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                addProgress(player, QuestType.PLAYTIME, "", 1);
                addProgress(player, QuestType.SURVIVE, "", 1);
                checkDeadlines(player);
            }
        }, 1200L, 1200L);

        // Obtain-item quests: check inventories every second.
        Bukkit.getScheduler().runTaskTimer(this, this::scanObtainQuests, 40L, 20L);

        for (Player player : Bukkit.getOnlinePlayers()) {
            handleJoin(player);
        }
    }

    @Override
    public void onDisable() {
        Bukkit.removeRecipe(reviveKey);
        save();
    }

    private void loadSettings() {
        startingLives = Math.max(1, getConfig().getInt("starting-lives", 3));
        maxLives = Math.max(startingLives, getConfig().getInt("max-lives", 5));
        reviveLives = Math.max(1, Math.min(maxLives, getConfig().getInt("revive-lives", 1)));
        maxBonusHearts = Math.max(0, getConfig().getInt("max-bonus-hearts", 10));
    }

    private void save() {
        try {
            data.save(dataFile);
            dirty = false;
        } catch (IOException ex) {
            getLogger().severe("Could not save data.yml: " + ex.getMessage());
        }
    }

    private void saveQuestDefs() {
        try {
            questDefs.save(questsFile);
        } catch (IOException ex) {
            getLogger().severe("Could not save quests.yml: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ lives data

    private int getLives(UUID id) {
        return data.getInt("lives." + id, startingLives);
    }

    private boolean isEliminated(UUID id) {
        return data.contains("eliminated." + id);
    }

    /**
     * Sets a player's lives (capped at max-lives). Reaching 0 eliminates (and bans) them;
     * going above 0 while eliminated revives (and pardons) them.
     */
    private void applyLives(OfflinePlayer target, int lives) {
        UUID id = target.getUniqueId();
        String name = target.getName() != null ? target.getName() : id.toString();
        lives = Math.max(0, Math.min(lives, maxLives));
        data.set("lives." + id, lives);

        boolean wasEliminated = isEliminated(id);
        if (lives == 0 && !wasEliminated) {
            data.set("eliminated." + id, name);
            Bukkit.broadcast(msg("eliminated", Placeholder.unparsed("player", name)));
            long delay = getConfig().getLong("ban-delay-ticks", 40L);
            String reason = getConfig().getString("ban-reason", "You ran out of lives.");
            Bukkit.getScheduler().runTaskLater(this, () ->
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "ban " + name + " " + reason), delay);
        } else if (lives > 0 && wasEliminated) {
            data.set("eliminated." + id, null);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "pardon " + name);
            Bukkit.broadcast(msg("revived", Placeholder.unparsed("player", name)));
        }
        save();

        Player online = Bukkit.getPlayer(id);
        if (online != null) {
            updateDisplay(online);
        }
    }

    /** Gives lives up to the maximum; anything above it becomes Life Heart items. */
    private void giveLives(Player player, int amount) {
        int current = getLives(player.getUniqueId());
        int add = Math.min(maxLives - current, amount);
        if (add > 0) {
            applyLives(player, current + add);
        }
        int overflow = amount - Math.max(0, add);
        if (overflow > 0) {
            giveItem(player, createLifeItem(overflow));
            player.sendMessage(msg("lives-overflow", Placeholder.unparsed("amount", String.valueOf(overflow))));
        }
    }

    // ------------------------------------------------------------------ bonus hearts (max health)

    private void applyBonusHealth(Player player, boolean heal) {
        AttributeInstance attribute = player.getAttribute(Attribute.MAX_HEALTH);
        if (attribute == null) {
            return;
        }
        int bonus = data.getInt("bonus." + player.getUniqueId(), 0);
        double target = Math.max(2.0, 20.0 + bonus * 2.0);
        if (attribute.getBaseValue() != target) {
            attribute.setBaseValue(target);
        }
        if (player.getHealth() > attribute.getValue()) {
            player.setHealth(attribute.getValue());
        }
        if (heal) {
            player.setHealth(attribute.getValue());
        }
    }

    // ------------------------------------------------------------------ display

    private Component hearts(int lives) {
        Component full = MM.deserialize(getConfig().getString("hearts.full", "<red>❤"));
        Component empty = MM.deserialize(getConfig().getString("hearts.empty", "<dark_gray>❤"));
        int total = Math.max(startingLives, lives);
        Component result = Component.empty();
        for (int i = 0; i < total; i++) {
            result = result.append(i < lives ? full : empty);
        }
        return result;
    }

    /** Shows hearts after the name above the head (scoreboard team suffix) and in the tab list. */
    private void updateDisplay(Player player) {
        int lives = getLives(player.getUniqueId());
        Component suffix = Component.space().append(hearts(lives));

        Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        String teamName = "lives_" + lives;
        Team team = board.getTeam(teamName);
        if (team == null) {
            team = board.registerNewTeam(teamName);
        }
        team.suffix(suffix);
        team.addEntry(player.getName());

        player.playerListName(Component.text(player.getName()).append(suffix));
    }

    // ------------------------------------------------------------------ events: lives

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        handleJoin(event.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        prompts.remove(event.getPlayer().getUniqueId());
        packLoaded.remove(event.getPlayer().getUniqueId());
        textureOverride.remove(event.getPlayer().getUniqueId());
    }

    private void handleJoin(Player player) {
        UUID id = player.getUniqueId();
        if (isEliminated(id)) {
            // They got back in, so an admin pardoned them manually: treat it as a revive.
            data.set("eliminated." + id, null);
            data.set("lives." + id, reviveLives);
        } else if (!data.contains("lives." + id)) {
            data.set("lives." + id, startingLives);
        }
        save();
        updateDisplay(player);
        applyBonusHealth(player, false);
        checkDeadlines(player);
        Bukkit.getScheduler().runTaskLater(this, () -> sendPack(player), 20L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> applyBonusHealth(player, true));
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID id = player.getUniqueId();
        handleSurviveDeath(player);
        if (isEliminated(id)) {
            return;
        }
        int lives = getLives(id) - 1;
        applyLives(player, lives);
        if (lives > 0) {
            player.sendMessage(msg("life-lost", Placeholder.unparsed("lives", String.valueOf(lives))));
        }
    }

    // ------------------------------------------------------------------ events: items and menus

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        if (isReviveItem(item)) {
            event.setCancelled(true);
            openMenu(event.getPlayer());
        } else if (isLifeItem(item)) {
            event.setCancelled(true);
            useLifeItem(event.getPlayer());
        }
    }

    /** Life Hearts and Totems of Revival can never be used as crafting ingredients. */
    @EventHandler
    public void onPrepareCraft(PrepareItemCraftEvent event) {
        for (ItemStack item : event.getInventory().getMatrix()) {
            if (isLifeItem(item) || isReviveItem(item)) {
                event.getInventory().setResult(null);
                return;
            }
        }
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        InventoryHolder holder = top.getHolder();
        if (!(holder instanceof ReviveMenu) && !(holder instanceof PagedMenu)) {
            return;
        }
        event.setCancelled(true);
        if (!top.equals(event.getClickedInventory())) {
            return;
        }
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) {
            return;
        }
        Player user = (Player) event.getWhoClicked();
        PersistentDataContainer pdc = clicked.getItemMeta().getPersistentDataContainer();

        if (holder instanceof ReviveMenu) {
            String key = pdc.get(targetKey, PersistentDataType.STRING);
            if (key == null) {
                return;
            }
            UUID targetId = UUID.fromString(key);
            user.closeInventory();
            if (!isEliminated(targetId)) {
                return;
            }
            if (!consumeReviveItem(user)) {
                user.sendMessage(msg("no-item"));
                return;
            }
            applyLives(Bukkit.getOfflinePlayer(targetId), reviveLives);
        } else if (holder instanceof PagedMenu menu) {
            handlePagedClick(user, menu, event, pdc, top);
        }
    }

    @EventHandler
    public void onMenuDrag(InventoryDragEvent event) {
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (holder instanceof ReviveMenu || holder instanceof PagedMenu) {
            event.setCancelled(true);
        }
    }

    private void handlePagedClick(Player user, PagedMenu menu, InventoryClickEvent event,
                                  PersistentDataContainer pdc, Inventory top) {
        String nav = pdc.get(navKey, PersistentDataType.STRING);
        if (nav != null) {
            switch (nav) {
                case "prev" -> openPagedMenu(user, menu.page - 1, menu.admin);
                case "next" -> openPagedMenu(user, menu.page + 1, menu.admin);
                case "create" -> {
                    if (user.hasPermission("lives.admin")) {
                        startCreate(user);
                    }
                }
                default -> {
                }
            }
            return;
        }

        String questId = pdc.get(questKey, PersistentDataType.STRING);
        Quest quest = questId == null ? null : quests.get(questId);
        if (quest == null) {
            return;
        }

        if (!menu.admin) {
            if (!isAssigned(user.getUniqueId(), quest.id())) {
                return;
            }
            claimQuest(user, quest);
            top.setItem(event.getSlot(), questIcon(user, quest));
            return;
        }

        if (!user.hasPermission("lives.admin")) {
            return;
        }
        ClickType click = event.getClick();
        switch (click) {
            case LEFT, SHIFT_LEFT -> askAssign(user, quest, true);
            case RIGHT -> askAssign(user, quest, false);
            case SHIFT_RIGHT -> askDelete(user, quest);
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ events: chat prompts

    /** While an admin is answering a question from the quest manager, their chat goes to the prompt. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!prompts.containsKey(player.getUniqueId())) {
            return;
        }
        event.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        Bukkit.getScheduler().runTask(this, () -> {
            Consumer<String> handler = prompts.remove(player.getUniqueId());
            if (handler == null) {
                return;
            }
            if (text.equalsIgnoreCase("cancel")) {
                player.sendMessage(msg("prompt-cancelled"));
                return;
            }
            handler.accept(text);
        });
    }

    private void ask(Player player, String question, Consumer<String> handler) {
        player.closeInventory();
        prompts.put(player.getUniqueId(), handler);
        player.sendMessage(MM.deserialize(question + " <dark_gray>(type <red>cancel</red> to stop)"));
    }

    private void info(Player player, String text) {
        player.sendMessage(MM.deserialize(text));
    }

    // ------------------------------------------------------------------ events: quest progress

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) {
            return;
        }
        if (event.getEntity() instanceof Player victim) {
            addProgress(killer, QuestType.HUNT, victim.getName().toLowerCase(Locale.ROOT), 1);
        }
        addProgress(killer, QuestType.KILL, event.getEntityType().name().toLowerCase(Locale.ROOT), 1);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) {
            return;
        }
        addProgress(player, QuestType.BREAK, event.getBlock().getType().name().toLowerCase(Locale.ROOT), 1);
    }

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        if (event.getState() == PlayerFishEvent.State.CAUGHT_FISH) {
            addProgress(event.getPlayer(), QuestType.FISH, "", 1);
        }
    }

    @EventHandler
    public void onAdvancement(PlayerAdvancementDoneEvent event) {
        String key = event.getAdvancement().getKey().toString().toLowerCase(Locale.ROOT);
        addProgress(event.getPlayer(), QuestType.ADVANCEMENT, key, 1);
    }

    private boolean isAssigned(UUID id, String questId) {
        return data.getBoolean("assigned." + id + "." + questId, false);
    }

    private void setAssigned(UUID id, String questId, boolean assigned) {
        String base = "quests." + id + "." + questId;
        if (assigned) {
            boolean failed = data.getBoolean(base + ".failed", false);
            if (isAssigned(id, questId) && !failed) {
                return; // already has it, keep their progress
            }
            data.set("assigned." + id + "." + questId, true);
            data.set("assignedAt." + id + "." + questId, System.currentTimeMillis());
            data.set(base, null); // fresh start: clears progress, claimed and failed
        } else {
            data.set("assigned." + id + "." + questId, null);
            data.set("assignedAt." + id + "." + questId, null);
        }
        dirty = true;
    }

    private int assignedCount(String questId) {
        ConfigurationSection section = data.getConfigurationSection("assigned");
        if (section == null) {
            return 0;
        }
        int count = 0;
        for (String key : section.getKeys(false)) {
            if (data.getBoolean("assigned." + key + "." + questId, false)) {
                count++;
            }
        }
        return count;
    }

    private void addProgress(Player player, QuestType type, String target, int amount) {
        for (Quest quest : quests.values()) {
            if (quest.type() != type) {
                continue;
            }
            if (!isAssigned(player.getUniqueId(), quest.id())) {
                continue;
            }
            if (!quest.targets().isEmpty() && !quest.targets().contains(target)) {
                continue;
            }
            String base = "quests." + player.getUniqueId() + "." + quest.id();
            if (data.getBoolean(base + ".claimed", false) || data.getBoolean(base + ".failed", false)) {
                continue;
            }
            int current = data.getInt(base + ".progress", 0);
            if (current >= quest.amount()) {
                continue;
            }
            int updated = Math.min(quest.amount(), current + amount);
            data.set(base + ".progress", updated);
            dirty = true;
            if (updated >= quest.amount()) {
                player.sendMessage(msg("quest-complete", Placeholder.component("quest", quest.name())));
            }
        }
    }

    // ------------------------------------------------------------------ obtain-item quests

    private void scanObtainQuests() {
        List<Quest> obtain = new ArrayList<>();
        for (Quest quest : quests.values()) {
            if (quest.type() == QuestType.OBTAIN) {
                obtain.add(quest);
            }
        }
        if (obtain.isEmpty()) {
            return;
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            for (Quest quest : obtain) {
                if (!isAssigned(player.getUniqueId(), quest.id())) {
                    continue;
                }
                String base = "quests." + player.getUniqueId() + "." + quest.id();
                if (data.getBoolean(base + ".claimed", false) || data.getBoolean(base + ".failed", false)) {
                    continue;
                }
                int current = data.getInt(base + ".progress", 0);
                if (current >= quest.amount()) {
                    continue;
                }
                int count = 0;
                for (ItemStack item : player.getInventory().getContents()) {
                    if (itemMatches(item, quest.targets())) {
                        count += item.getAmount();
                    }
                }
                int updated = Math.min(quest.amount(), Math.max(current, count));
                if (updated > current) {
                    data.set(base + ".progress", updated);
                    dirty = true;
                    if (updated >= quest.amount()) {
                        player.sendMessage(msg("quest-complete", Placeholder.component("quest", quest.name())));
                    }
                }
            }
        }
    }

    /** Targets look like "diamond" or "filled_map:treasure" (item, plus a word its name must contain). */
    private boolean itemMatches(ItemStack item, Set<String> targets) {
        if (item == null || item.getType().isAir()) {
            return false;
        }
        String material = item.getType().name().toLowerCase(Locale.ROOT);
        for (String target : targets) {
            int colon = target.indexOf(':');
            String targetMaterial = colon < 0 ? target : target.substring(0, colon);
            if (!material.equals(targetMaterial)) {
                continue;
            }
            if (colon < 0 || describe(item).contains(target.substring(colon + 1))) {
                return true;
            }
        }
        return false;
    }

    /** The item's names and translation keys as lowercase text (a buried treasure map has "treasure" in it). */
    private String describe(ItemStack item) {
        StringBuilder text = new StringBuilder();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (meta.hasItemName()) {
                text.append(componentText(meta.itemName())).append(' ');
            }
            if (meta.hasDisplayName()) {
                text.append(componentText(meta.displayName())).append(' ');
            }
        }
        return text.toString().toLowerCase(Locale.ROOT);
    }

    private String componentText(Component component) {
        StringBuilder text = new StringBuilder();
        if (component instanceof TranslatableComponent translatable) {
            text.append(translatable.key()).append(' ');
        }
        text.append(PlainTextComponentSerializer.plainText().serialize(component));
        for (Component child : component.children()) {
            text.append(' ').append(componentText(child));
        }
        return text.toString();
    }

    private String prettyItems(List<String> targets) {
        List<String> names = new ArrayList<>();
        for (String target : targets) {
            String[] parts = target.split(":", 2);
            String name = parts[0].toLowerCase(Locale.ROOT).replace('_', ' ');
            names.add(parts.length > 1 ? name + " (" + parts[1] + ")" : name);
        }
        return String.join(", ", names);
    }

    /** Dying fails an unfinished survive quest (if it has a punishment) or resets its timer. */
    private void handleSurviveDeath(Player player) {
        for (Quest quest : quests.values()) {
            if (quest.type() != QuestType.SURVIVE || !isAssigned(player.getUniqueId(), quest.id())) {
                continue;
            }
            String base = "quests." + player.getUniqueId() + "." + quest.id();
            int progress = data.getInt(base + ".progress", 0);
            if (data.getBoolean(base + ".claimed", false) || data.getBoolean(base + ".failed", false)
                    || progress >= quest.amount()) {
                continue;
            }
            if (quest.hasPunishment()) {
                failQuest(player, quest);
            } else if (progress > 0) {
                data.set(base + ".progress", 0);
                dirty = true;
                player.sendMessage(Component.text("Your survival timer was reset: ", NamedTextColor.RED)
                        .append(quest.name()));
            }
        }
    }

    /** Fails every assigned quest whose time limit has run out. */
    private void checkDeadlines(Player player) {
        long now = System.currentTimeMillis();
        for (Quest quest : quests.values()) {
            if (quest.timeLimit() <= 0 || !isAssigned(player.getUniqueId(), quest.id())) {
                continue;
            }
            String base = "quests." + player.getUniqueId() + "." + quest.id();
            if (data.getBoolean(base + ".claimed", false) || data.getBoolean(base + ".failed", false)
                    || data.getInt(base + ".progress", 0) >= quest.amount()) {
                continue;
            }
            long since = data.getLong("assignedAt." + player.getUniqueId() + "." + quest.id(), 0L);
            if (since > 0 && now - since >= quest.timeLimit() * 60_000L) {
                failQuest(player, quest);
            }
        }
    }

    private void failQuest(Player player, Quest quest) {
        String base = "quests." + player.getUniqueId() + "." + quest.id();
        data.set(base + ".failed", true);
        dirty = true;
        applyPunishment(player, quest);
        player.sendMessage(msg("quest-failed",
                Placeholder.component("quest", quest.name()),
                Placeholder.unparsed("punishment", punishmentText(quest))));
    }

    private void applyPunishment(Player player, Quest quest) {
        UUID id = player.getUniqueId();
        if (quest.punishHearts() > 0) {
            int current = data.getInt("bonus." + id, 0);
            data.set("bonus." + id, Math.max(-9, current - quest.punishHearts()));
            applyBonusHealth(player, false);
        }
        if (quest.punishLives() > 0) {
            int floor = getConfig().getBoolean("punishment-can-eliminate", false) ? 0 : 1;
            int current = getLives(id);
            int next = Math.max(floor, current - quest.punishLives());
            if (next < current) {
                applyLives(player, next);
            }
        }
        save();
    }

    private String punishmentText(Quest quest) {
        List<String> parts = new ArrayList<>();
        if (quest.punishLives() > 0) {
            parts.add("-" + quest.punishLives() + (quest.punishLives() == 1 ? " life" : " lives"));
        }
        if (quest.punishHearts() > 0) {
            parts.add("-" + quest.punishHearts() + (quest.punishHearts() == 1 ? " max heart" : " max hearts"));
        }
        return parts.isEmpty() ? "none" : String.join(", ", parts);
    }

    private String formatMinutes(long minutes) {
        if (minutes >= 60) {
            return (minutes / 60) + "h " + (minutes % 60) + "m";
        }
        return minutes + "m";
    }

    private void claimQuest(Player player, Quest quest) {
        String base = "quests." + player.getUniqueId() + "." + quest.id();
        boolean claimed = data.getBoolean(base + ".claimed", false);
        int progress = data.getInt(base + ".progress", 0);
        if (claimed || progress < quest.amount() || data.getBoolean(base + ".failed", false)) {
            return;
        }
        data.set(base + ".claimed", true);
        dirty = true;

        if (quest.bonusHearts() > 0) {
            int current = data.getInt("bonus." + player.getUniqueId(), 0);
            int add = Math.min(quest.bonusHearts(), maxBonusHearts - current);
            if (add > 0) {
                data.set("bonus." + player.getUniqueId(), current + add);
                applyBonusHealth(player, false);
            }
        }
        for (ItemStack item : quest.items()) {
            giveItem(player, item.clone());
        }
        if (quest.lives() > 0) {
            giveLives(player, quest.lives());
        }
        save();
        player.sendMessage(msg("quest-claimed-msg", Placeholder.component("quest", quest.name())));
    }

    // ------------------------------------------------------------------ quest definitions (quests.yml)

    private void loadQuests() {
        quests.clear();
        ConfigurationSection section = questDefs.getConfigurationSection("quests");
        if (section == null) {
            return;
        }
        for (String id : section.getKeys(false)) {
            ConfigurationSection q = section.getConfigurationSection(id);
            if (q == null) {
                continue;
            }
            QuestType type;
            try {
                type = QuestType.valueOf(q.getString("type", "KILL").toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Quest " + id + " has an unknown type, skipping it.");
                continue;
            }
            Material icon = Material.matchMaterial(q.getString("icon", "PAPER"));
            if (icon == null) {
                icon = Material.PAPER;
            }
            Set<String> targets = new HashSet<>();
            for (String target : q.getStringList("targets")) {
                targets.add(target.toLowerCase(Locale.ROOT));
            }
            List<ItemStack> items = new ArrayList<>();
            for (String entry : q.getStringList("rewards.items")) {
                String[] parts = entry.split(":");
                Material material = Material.matchMaterial(parts[0].trim());
                if (material == null) {
                    getLogger().warning("Quest " + id + " has an unknown reward item: " + entry);
                    continue;
                }
                int count = parts.length > 1 ? Math.max(1, parse(parts[1].trim(), 1)) : 1;
                items.add(new ItemStack(material, count));
            }
            quests.put(id, new Quest(
                    id,
                    MM.deserialize(q.getString("name", id)),
                    icon,
                    q.getStringList("description"),
                    type,
                    targets,
                    Math.max(1, q.getInt("amount", 1)),
                    Math.max(0, q.getInt("rewards.lives", 0)),
                    Math.max(0, q.getInt("rewards.bonus-hearts", 0)),
                    items,
                    Math.max(0, q.getInt("time-limit", 0)),
                    Math.max(0, q.getInt("punishment.lives", 0)),
                    Math.max(0, q.getInt("punishment.bonus-hearts", 0))));
        }
    }

    private void deleteQuest(String id) {
        questDefs.set("quests." + id, null);
        saveQuestDefs();
        loadQuests();
    }

    // ------------------------------------------------------------------ quest creation wizard (chat)

    private void startCreate(Player admin) {
        ask(admin, "<gold>[New quest] <white>Type a short id with no spaces. Example: <yellow>zombie_slayer", answer -> {
            String id = answer.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "");
            if (id.isEmpty() || quests.containsKey(id)) {
                info(admin, "<red>That id is empty or already used. Open /questadmin and try again.");
                return;
            }
            Draft draft = new Draft();
            draft.id = id;
            askName(admin, draft);
        });
    }

    private void askName(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Type the name players will see. You can use colors, e.g. <yellow>\\<green>Zombie Slayer",
                answer -> {
                    draft.name = answer;
                    askType(admin, draft);
                });
    }

    private void askType(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>What must players do? Type one: <yellow>KILL</yellow> (kill mobs), "
                        + "<yellow>BREAK</yellow> (mine blocks), <yellow>FISH</yellow> (catch fish), "
                        + "<yellow>PLAYTIME</yellow> (minutes online), <yellow>ADVANCEMENT</yellow>, "
                        + "<yellow>HUNT</yellow> (kill a specific player), "
                        + "<yellow>SURVIVE</yellow> (stay alive for some minutes), "
                        + "<yellow>OBTAIN</yellow> (get items in your inventory)",
                answer -> {
                    try {
                        draft.type = QuestType.valueOf(answer.toUpperCase(Locale.ROOT));
                    } catch (IllegalArgumentException ex) {
                        info(admin, "<red>That is not one of the types. Try again.");
                        askType(admin, draft);
                        return;
                    }
                    if (draft.type == QuestType.FISH || draft.type == QuestType.PLAYTIME || draft.type == QuestType.SURVIVE) {
                        askAmount(admin, draft);
                    } else {
                        askTargets(admin, draft);
                    }
                });
    }

    private void askTargets(Player admin, Draft draft) {
        String example = switch (draft.type) {
            case KILL -> "mob names like <yellow>ZOMBIE, CREEPER</yellow> (or <yellow>ENDER_DRAGON</yellow>)";
            case BREAK -> "block names like <yellow>DIAMOND_ORE, DEEPSLATE_DIAMOND_ORE</yellow>";
            case HUNT -> "the exact name of the player to hunt, like <yellow>NumberJacker</yellow>";
            case OBTAIN -> "item names like <yellow>DIAMOND</yellow>. For a treasure map type <yellow>FILLED_MAP:treasure</yellow>";
            default -> "advancement ids like <yellow>minecraft:story/enter_the_nether</yellow>";
        };
        ask(admin, "<gold>[New quest] <white>What counts? Type " + example + ". Separate several with commas.",
                answer -> {
                    List<String> targets = new ArrayList<>();
                    for (String part : answer.split(",")) {
                        String target = part.trim();
                        if (target.isEmpty()) {
                            continue;
                        }
                        if (draft.type == QuestType.OBTAIN) {
                            String[] parts = target.split(":", 2);
                            Material material = Material.matchMaterial(parts[0].trim());
                            if (material == null) {
                                info(admin, "<red>Unknown item: " + parts[0].trim() + ". Try again.");
                                askTargets(admin, draft);
                                return;
                            }
                            String keyword = parts.length > 1 ? parts[1].trim().toLowerCase(Locale.ROOT) : "";
                            targets.add(keyword.isEmpty() ? material.name() : material.name() + ":" + keyword);
                            continue;
                        }
                        if (draft.type == QuestType.BREAK && Material.matchMaterial(target) == null) {
                            info(admin, "<red>Unknown block: " + target + ". Try again.");
                            askTargets(admin, draft);
                            return;
                        }
                        if (draft.type == QuestType.HUNT) {
                            targets.add(target);
                        } else {
                            targets.add(draft.type == QuestType.ADVANCEMENT
                                    ? target.toLowerCase(Locale.ROOT) : target.toUpperCase(Locale.ROOT));
                        }
                    }
                    if (targets.isEmpty()) {
                        info(admin, "<red>You need at least one. Try again.");
                        askTargets(admin, draft);
                        return;
                    }
                    draft.targets = targets;
                    askAmount(admin, draft);
                });
    }

    private void askAmount(Player admin, Draft draft) {
        String unit = switch (draft.type) {
            case PLAYTIME -> "How many <yellow>minutes</yellow> online?";
            case SURVIVE -> "How many <yellow>minutes</yellow> must they stay alive? (1 hour = 60)";
            case ADVANCEMENT -> "How many times? (usually <yellow>1</yellow>)";
            default -> "How many are needed?";
        };
        ask(admin, "<gold>[New quest] <white>" + unit + " Type a number.", answer -> {
            int amount = parse(answer, -1);
            if (amount < 1) {
                info(admin, "<red>Enter a number of 1 or more.");
                askAmount(admin, draft);
                return;
            }
            draft.amount = amount;
            askLives(admin, draft);
        });
    }

    private void askLives(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Reward: how many <red>lives</red>? Type a number (0 for none).", answer -> {
            int lives = parse(answer, -1);
            if (lives < 0) {
                info(admin, "<red>Enter 0 or a positive number.");
                askLives(admin, draft);
                return;
            }
            draft.lives = lives;
            askBonus(admin, draft);
        });
    }

    private void askBonus(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Reward: how many extra <red>max health hearts</red>? Type a number (0 for none).",
                answer -> {
                    int bonus = parse(answer, -1);
                    if (bonus < 0) {
                        info(admin, "<red>Enter 0 or a positive number.");
                        askBonus(admin, draft);
                        return;
                    }
                    draft.bonusHearts = bonus;
                    askItems(admin, draft);
                });
    }

    private void askItems(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Reward items? Type like <yellow>DIAMOND:5, GOLDEN_APPLE:2</yellow> or <yellow>none</yellow>.",
                answer -> {
                    List<String> items = new ArrayList<>();
                    if (!answer.equalsIgnoreCase("none")) {
                        for (String part : answer.split(",")) {
                            String entry = part.trim();
                            if (entry.isEmpty()) {
                                continue;
                            }
                            String materialName = entry.split(":")[0].trim();
                            if (Material.matchMaterial(materialName) == null) {
                                info(admin, "<red>Unknown item: " + materialName + ". Try again.");
                                askItems(admin, draft);
                                return;
                            }
                            items.add(entry.toUpperCase(Locale.ROOT));
                        }
                    }
                    draft.items = items;
                    askIcon(admin, draft);
                });
    }

    private void askIcon(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Menu icon? Type an item name like <yellow>DIAMOND</yellow>, or <yellow>hand</yellow> "
                        + "to use what you are holding. (Avoid tools and armor, they show extra text.)",
                answer -> {
                    Material icon;
                    if (answer.equalsIgnoreCase("hand")) {
                        icon = admin.getInventory().getItemInMainHand().getType();
                        if (icon.isAir()) {
                            icon = Material.PAPER;
                        }
                    } else {
                        icon = Material.matchMaterial(answer);
                        if (icon == null || icon.isAir()) {
                            info(admin, "<red>Unknown item. Try again.");
                            askIcon(admin, draft);
                            return;
                        }
                    }
                    draft.icon = icon;
                    askTimeLimit(admin, draft);
                });
    }

    private void askTimeLimit(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Time limit in <yellow>minutes</yellow>? If the player has not finished by then, "
                        + "they <red>fail</red> the quest. Type <yellow>0</yellow> for no limit.",
                answer -> {
                    int minutes = parse(answer, -1);
                    if (minutes < 0) {
                        info(admin, "<red>Enter 0 or a positive number.");
                        askTimeLimit(admin, draft);
                        return;
                    }
                    draft.timeLimit = minutes;
                    if (minutes == 0 && draft.type != QuestType.SURVIVE) {
                        finishDraft(admin, draft);
                    } else {
                        askPunishLives(admin, draft);
                    }
                });
    }

    private void askPunishLives(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Punishment for failing: how many <red>lives</red> are lost? Type a number (0 for none). "
                        + "<gray>(A survive quest also fails the moment the player dies, if it has a punishment.)",
                answer -> {
                    int lives = parse(answer, -1);
                    if (lives < 0) {
                        info(admin, "<red>Enter 0 or a positive number.");
                        askPunishLives(admin, draft);
                        return;
                    }
                    draft.punishLives = lives;
                    askPunishHearts(admin, draft);
                });
    }

    private void askPunishHearts(Player admin, Draft draft) {
        ask(admin, "<gold>[New quest] <white>Punishment for failing: how many <red>max health hearts</red> are lost? Type a number (0 for none).",
                answer -> {
                    int hearts = parse(answer, -1);
                    if (hearts < 0) {
                        info(admin, "<red>Enter 0 or a positive number.");
                        askPunishHearts(admin, draft);
                        return;
                    }
                    draft.punishHearts = hearts;
                    finishDraft(admin, draft);
                });
    }

    private void finishDraft(Player admin, Draft draft) {
        String targetText = String.join(", ", draft.targets).toLowerCase(Locale.ROOT).replace('_', ' ');
        String description = switch (draft.type) {
            case KILL -> "Kill " + draft.amount + " " + targetText + ".";
            case BREAK -> "Break " + draft.amount + " " + targetText + ".";
            case FISH -> "Catch " + draft.amount + " fish.";
            case PLAYTIME -> "Play for " + draft.amount + " minutes.";
            case ADVANCEMENT -> "Earn: " + targetText + ".";
            case HUNT -> "Hunt down and kill " + String.join(", ", draft.targets) + ".";
            case SURVIVE -> "Survive for " + draft.amount + " minutes without dying.";
            case OBTAIN -> "Obtain " + draft.amount + " " + prettyItems(draft.targets) + ".";
        };

        String base = "quests." + draft.id;
        questDefs.set(base + ".name", draft.name);
        questDefs.set(base + ".icon", draft.icon.name());
        questDefs.set(base + ".description", List.of("<gray>" + description));
        questDefs.set(base + ".type", draft.type.name());
        questDefs.set(base + ".targets", draft.targets);
        questDefs.set(base + ".amount", draft.amount);
        questDefs.set(base + ".rewards.lives", draft.lives);
        questDefs.set(base + ".rewards.bonus-hearts", draft.bonusHearts);
        questDefs.set(base + ".rewards.items", draft.items);
        questDefs.set(base + ".time-limit", draft.timeLimit);
        questDefs.set(base + ".punishment.lives", draft.punishLives);
        questDefs.set(base + ".punishment.bonus-hearts", draft.punishHearts);
        saveQuestDefs();
        loadQuests();

        admin.sendMessage(msg("quest-created", Placeholder.unparsed("id", draft.id)));
        openPagedMenu(admin, 0, true);
    }

    private void askAssign(Player admin, Quest quest, boolean assign) {
        String action = assign ? "give" : "take";
        String preposition = assign ? "to" : "from";
        ask(admin, "<gold>[Quests] <white>Type the name of the player to " + action + " this quest " + preposition
                        + ", or <yellow>all</yellow> for everyone who has joined the server.",
                answer -> applyAssignment(admin, answer, quest, assign));
    }

    private void askDelete(Player admin, Quest quest) {
        ask(admin, "<gold>[Quests] <white>Type <red>confirm</red> to delete the quest <yellow>" + quest.id() + "</yellow>.",
                answer -> {
                    if (answer.equalsIgnoreCase("confirm")) {
                        deleteQuest(quest.id());
                        admin.sendMessage(msg("quest-deleted", Placeholder.unparsed("id", quest.id())));
                        openPagedMenu(admin, 0, true);
                    } else {
                        admin.sendMessage(msg("prompt-cancelled"));
                    }
                });
    }

    private Set<UUID> knownPlayers() {
        Set<UUID> ids = new HashSet<>();
        ConfigurationSection section = data.getConfigurationSection("lives");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                try {
                    ids.add(UUID.fromString(key));
                } catch (IllegalArgumentException ignored) {
                    // skip bad keys
                }
            }
        }
        for (Player player : Bukkit.getOnlinePlayers()) {
            ids.add(player.getUniqueId());
        }
        return ids;
    }

    private void applyAssignment(CommandSender actor, String who, Quest quest, boolean assign) {
        if (who.equalsIgnoreCase("all")) {
            Set<UUID> ids = knownPlayers();
            for (UUID id : ids) {
                setAssigned(id, quest.id(), assign);
            }
            if (assign) {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendMessage(msg("quest-assigned", Placeholder.component("quest", quest.name())));
                }
            }
            actor.sendMessage(msg(assign ? "quest-assigned-all" : "quest-unassigned-all",
                    Placeholder.unparsed("quest", quest.id()),
                    Placeholder.unparsed("count", String.valueOf(ids.size()))));
            return;
        }
        OfflinePlayer target = findPlayer(who);
        if (target == null) {
            actor.sendMessage(msg("unknown-player"));
            return;
        }
        setAssigned(target.getUniqueId(), quest.id(), assign);
        Player online = target.getPlayer();
        if (assign && online != null) {
            online.sendMessage(msg("quest-assigned", Placeholder.component("quest", quest.name())));
        }
        actor.sendMessage(msg(assign ? "quest-assigned-admin" : "quest-unassigned-admin",
                Placeholder.unparsed("quest", quest.id()),
                Placeholder.unparsed("player", String.valueOf(target.getName()))));
    }

    // ------------------------------------------------------------------ quest menus

    private String rewardText(Quest quest) {
        List<String> parts = new ArrayList<>();
        if (quest.lives() > 0) {
            parts.add("+" + quest.lives() + (quest.lives() == 1 ? " life" : " lives"));
        }
        if (quest.bonusHearts() > 0) {
            parts.add("+" + quest.bonusHearts() + (quest.bonusHearts() == 1 ? " max heart" : " max hearts"));
        }
        for (ItemStack item : quest.items()) {
            parts.add(item.getAmount() + "x " + item.getType().name().toLowerCase(Locale.ROOT).replace('_', ' '));
        }
        return parts.isEmpty() ? "none" : String.join(", ", parts);
    }

    private Component plain(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack questIcon(Player player, Quest quest) {
        String base = "quests." + player.getUniqueId() + "." + quest.id();
        int progress = Math.min(quest.amount(), data.getInt(base + ".progress", 0));
        boolean claimed = data.getBoolean(base + ".claimed", false);
        boolean failed = data.getBoolean(base + ".failed", false);
        boolean done = progress >= quest.amount();

        ItemStack item = new ItemStack(quest.icon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plain(quest.name()));

        List<Component> lore = new ArrayList<>();
        for (String line : quest.description()) {
            lore.add(plain(MM.deserialize(line)));
        }
        lore.add(Component.empty());
        lore.add(plain(msg("quest-progress",
                Placeholder.unparsed("current", String.valueOf(progress)),
                Placeholder.unparsed("amount", String.valueOf(quest.amount())))));
        lore.add(plain(msg("quest-rewards", Placeholder.unparsed("rewards", rewardText(quest)))));
        if (quest.timeLimit() > 0 && !done && !failed && !claimed) {
            long since = data.getLong("assignedAt." + player.getUniqueId() + "." + quest.id(), 0L);
            long left = since <= 0 ? quest.timeLimit()
                    : Math.max(0L, quest.timeLimit() - (System.currentTimeMillis() - since) / 60_000L);
            lore.add(plain(msg("quest-time-left", Placeholder.unparsed("time", formatMinutes(left)))));
        }
        if (quest.hasPunishment() && !claimed) {
            lore.add(plain(msg("quest-punishment", Placeholder.unparsed("punishment", punishmentText(quest)))));
        }
        String status = failed ? "quest-status-failed"
                : (claimed ? "quest-status-claimed" : (done ? "quest-status-claim" : "quest-status-incomplete"));
        lore.add(plain(msg(status)));
        meta.lore(lore);

        if (done && !claimed && !failed) {
            meta.setEnchantmentGlintOverride(true);
        }
        meta.getPersistentDataContainer().set(questKey, PersistentDataType.STRING, quest.id());
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack adminQuestIcon(Quest quest) {
        ItemStack item = new ItemStack(quest.icon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plain(quest.name()));

        List<Component> lore = new ArrayList<>();
        for (String line : quest.description()) {
            lore.add(plain(MM.deserialize(line)));
        }
        lore.add(Component.empty());
        lore.add(plain(msg("admin-quest-type",
                Placeholder.unparsed("type", quest.type().name()),
                Placeholder.unparsed("amount", String.valueOf(quest.amount())))));
        if (!quest.targets().isEmpty()) {
            lore.add(plain(msg("admin-quest-targets",
                    Placeholder.unparsed("targets", String.join(", ", quest.targets())))));
        }
        lore.add(plain(msg("quest-rewards", Placeholder.unparsed("rewards", rewardText(quest)))));
        if (quest.timeLimit() > 0) {
            lore.add(plain(msg("admin-quest-limit", Placeholder.unparsed("time", formatMinutes(quest.timeLimit())))));
        }
        if (quest.hasPunishment()) {
            lore.add(plain(msg("quest-punishment", Placeholder.unparsed("punishment", punishmentText(quest)))));
        }
        lore.add(plain(msg("admin-quest-assigned",
                Placeholder.unparsed("count", String.valueOf(assignedCount(quest.id()))))));
        lore.add(Component.empty());
        lore.add(plain(msg("admin-hint-left")));
        lore.add(plain(msg("admin-hint-right")));
        lore.add(plain(msg("admin-hint-shift")));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(questKey, PersistentDataType.STRING, quest.id());
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack pane() {
        Material material = Material.matchMaterial(getConfig().getString("gui.border", "BLACK_STAINED_GLASS_PANE"));
        if (material == null) {
            material = Material.BLACK_STAINED_GLASS_PANE;
        }
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(Component.text(" "));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack button(Material material, Component name, List<Component> lore, String nav) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plain(name));
        if (!lore.isEmpty()) {
            meta.lore(lore);
        }
        if (nav != null) {
            meta.getPersistentDataContainer().set(navKey, PersistentDataType.STRING, nav);
        }
        item.setItemMeta(meta);
        return item;
    }

    private void openPagedMenu(Player viewer, int page, boolean admin) {
        List<Quest> list = new ArrayList<>();
        for (Quest quest : quests.values()) {
            if (admin || isAssigned(viewer.getUniqueId(), quest.id())) {
                list.add(quest);
            }
        }
        int pages = Math.max(1, (list.size() + CONTENT_SLOTS.length - 1) / CONTENT_SLOTS.length);
        page = Math.max(0, Math.min(page, pages - 1));

        boolean textured = textured(viewer);
        Component title = textured
                ? texturedTitle(admin ? '\uE101' : '\uE100')
                : MM.deserialize(getConfig().getString(
                        admin ? "gui.admin-title" : "gui.title",
                        admin ? "<dark_red>Quest Manager" : "<gold>Your Quests"));
        PagedMenu menu = new PagedMenu(title, page, admin);
        Inventory inventory = menu.getInventory();

        // frame (only needed without the texture pack, the pack paints its own frame)
        if (!textured) {
            ItemStack frame = pane();
            for (int slot = 0; slot < 54; slot++) {
                if (slot < 9 || slot >= 45 || slot % 9 == 0 || slot % 9 == 8) {
                    inventory.setItem(slot, frame);
                }
            }
        }

        // header
        if (admin) {
            inventory.setItem(4, button(Material.EMERALD, msg("admin-create-name"),
                    List.of(plain(msg("admin-create-lore"))), "create"));
        } else {
            int claimed = 0;
            for (Quest quest : list) {
                if (data.getBoolean("quests." + viewer.getUniqueId() + "." + quest.id() + ".claimed", false)) {
                    claimed++;
                }
            }
            inventory.setItem(4, button(Material.BOOK,
                    MM.deserialize(getConfig().getString("gui.header-name", "<gold>Your Quests")),
                    List.of(plain(msg("gui-header-lore",
                            Placeholder.unparsed("done", String.valueOf(claimed)),
                            Placeholder.unparsed("total", String.valueOf(list.size()))))), null));
        }

        // quests
        int start = page * CONTENT_SLOTS.length;
        for (int i = 0; i < CONTENT_SLOTS.length; i++) {
            int index = start + i;
            if (index >= list.size()) {
                break;
            }
            Quest quest = list.get(index);
            inventory.setItem(CONTENT_SLOTS[i], admin ? adminQuestIcon(quest) : questIcon(viewer, quest));
        }
        if (list.isEmpty()) {
            inventory.setItem(22, button(Material.BARRIER,
                    admin ? msg("admin-create-name") : msg("gui-empty-name"),
                    List.of(plain(msg(admin ? "admin-empty-lore" : "gui-empty-lore"))), admin ? "create" : null));
        }

        // page controls
        if (page > 0) {
            inventory.setItem(48, button(Material.ARROW, msg("gui-prev"), List.of(), "prev"));
        }
        inventory.setItem(49, button(Material.PAPER, msg("gui-page",
                Placeholder.unparsed("page", String.valueOf(page + 1)),
                Placeholder.unparsed("pages", String.valueOf(pages))), List.of(), null));
        if (page < pages - 1) {
            inventory.setItem(50, button(Material.ARROW, msg("gui-next"), List.of(), "next"));
        }

        viewer.openInventory(inventory);
    }

    // ------------------------------------------------------------------ revive item and life item

    private ItemStack createReviveItem(int amount) {
        ItemStack item = new ItemStack(Material.RECOVERY_COMPASS, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(MM.deserialize(getConfig().getString("item.name", "<light_purple>Totem of Revival"))
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(loreFrom("item.lore"));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(reviveKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack createLifeItem(int amount) {
        Material material = Material.matchMaterial(getConfig().getString("life-item.material", "ECHO_SHARD"));
        if (material == null) {
            material = Material.ECHO_SHARD;
        }
        ItemStack item = new ItemStack(material, amount);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(MM.deserialize(getConfig().getString("life-item.name", "<red>Life Heart"))
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(loreFrom("life-item.lore"));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(lifeKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private List<Component> loreFrom(String path) {
        List<Component> lore = new ArrayList<>();
        for (String line : getConfig().getStringList(path)) {
            lore.add(MM.deserialize(line).decoration(TextDecoration.ITALIC, false));
        }
        return lore;
    }

    private boolean isReviveItem(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(reviveKey, PersistentDataType.BYTE);
    }

    private boolean isLifeItem(ItemStack item) {
        return item != null && item.hasItemMeta()
                && item.getItemMeta().getPersistentDataContainer().has(lifeKey, PersistentDataType.BYTE);
    }

    private void useLifeItem(Player player) {
        UUID id = player.getUniqueId();
        int lives = getLives(id);
        if (lives >= maxLives) {
            player.sendMessage(msg("lives-full", Placeholder.unparsed("max", String.valueOf(maxLives))));
            return;
        }
        PlayerInventory inventory = player.getInventory();
        ItemStack hand = inventory.getItemInMainHand();
        if (hand.getAmount() <= 1) {
            inventory.setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
            inventory.setItemInMainHand(hand);
        }
        applyLives(player, lives + 1);
        player.sendMessage(msg("life-gained", Placeholder.unparsed("lives", String.valueOf(lives + 1))));
    }

    private boolean consumeReviveItem(Player player) {
        PlayerInventory inventory = player.getInventory();
        for (int i = 0; i < inventory.getSize(); i++) {
            ItemStack item = inventory.getItem(i);
            if (isReviveItem(item)) {
                if (item.getAmount() <= 1) {
                    inventory.setItem(i, null);
                } else {
                    item.setAmount(item.getAmount() - 1);
                }
                return true;
            }
        }
        return false;
    }

    private void giveItem(Player player, ItemStack item) {
        player.getInventory().addItem(item).values()
                .forEach(leftover -> player.getWorld().dropItem(player.getLocation(), leftover));
    }

    private void registerRecipe() {
        try {
            ShapedRecipe recipe = new ShapedRecipe(reviveKey, createReviveItem(1));
            List<String> shape = getConfig().getStringList("recipe.shape");
            recipe.shape(shape.toArray(new String[0]));

            ConfigurationSection ingredients = getConfig().getConfigurationSection("recipe.ingredients");
            if (ingredients == null) {
                getLogger().warning("recipe.ingredients is missing, revive recipe not registered.");
                return;
            }
            for (String key : ingredients.getKeys(false)) {
                Material material = Material.matchMaterial(ingredients.getString(key, ""));
                if (material == null) {
                    getLogger().warning("Unknown material for recipe ingredient " + key);
                    continue;
                }
                recipe.setIngredient(key.charAt(0), material);
            }
            Bukkit.addRecipe(recipe);
        } catch (IllegalArgumentException ex) {
            getLogger().warning("Invalid revive recipe in config.yml: " + ex.getMessage());
        }
    }

    private void openMenu(Player viewer) {
        ConfigurationSection eliminated = data.getConfigurationSection("eliminated");
        if (eliminated == null || eliminated.getKeys(false).isEmpty()) {
            viewer.sendMessage(msg("no-eliminated"));
            return;
        }
        ReviveMenu menu = new ReviveMenu(textured(viewer)
                ? texturedTitle('\uE102')
                : MM.deserialize(getConfig().getString("menu.title", "<dark_purple>Choose a soul to revive")));

        int slot = 0;
        for (String key : eliminated.getKeys(false)) {
            if (slot >= 54) {
                break;
            }
            UUID id = UUID.fromString(key);
            ItemStack head = new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta = (SkullMeta) head.getItemMeta();
            meta.setOwningPlayer(Bukkit.getOfflinePlayer(id));
            meta.displayName(Component.text(eliminated.getString(key, "Unknown"), NamedTextColor.RED)
                    .decoration(TextDecoration.ITALIC, false));
            meta.lore(List.of(Component.text("Click to revive", NamedTextColor.GRAY)
                    .decoration(TextDecoration.ITALIC, false)));
            meta.getPersistentDataContainer().set(targetKey, PersistentDataType.STRING, key);
            head.setItemMeta(meta);
            menu.getInventory().setItem(slot++, head);
        }
        viewer.openInventory(menu.getInventory());
    }

    // ------------------------------------------------------------------ commands

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        switch (name) {
            case "withdraw" -> {
                return handleWithdraw(sender, args);
            }
            case "quests" -> {
                if (sender instanceof Player player) {
                    openPagedMenu(player, 0, false);
                } else {
                    sender.sendMessage(msg("players-only"));
                }
                return true;
            }
            case "questadmin" -> {
                return handleQuestAdmin(sender, args);
            }
            default -> {
                return handleLives(sender, args);
            }
        }
    }

    private boolean handleQuestAdmin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("lives.admin")) {
            sender.sendMessage(msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            if (sender instanceof Player player) {
                openPagedMenu(player, 0, true);
            } else {
                sender.sendMessage(msg("players-only"));
            }
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "assign", "unassign" -> {
                if (args.length < 3) {
                    sender.sendMessage(msg("questadmin-usage"));
                    return true;
                }
                Quest quest = quests.get(args[2].toLowerCase(Locale.ROOT));
                if (quest == null) {
                    sender.sendMessage(msg("unknown-quest"));
                    return true;
                }
                applyAssignment(sender, args[1], quest, sub.equals("assign"));
            }
            case "delete" -> {
                Quest quest = args.length > 1 ? quests.get(args[1].toLowerCase(Locale.ROOT)) : null;
                if (quest == null) {
                    sender.sendMessage(msg("unknown-quest"));
                    return true;
                }
                deleteQuest(quest.id());
                sender.sendMessage(msg("quest-deleted", Placeholder.unparsed("id", quest.id())));
            }
            case "list" -> sender.sendMessage(Component.text(
                    quests.isEmpty() ? "No quests yet." : "Quests: " + String.join(", ", quests.keySet()),
                    NamedTextColor.GRAY));
            default -> sender.sendMessage(msg("questadmin-usage"));
        }
        return true;
    }

    private boolean handleWithdraw(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(msg("players-only"));
            return true;
        }
        int amount = args.length > 0 ? parse(args[0], -1) : 1;
        if (amount < 1) {
            player.sendMessage(msg("invalid-number"));
            return true;
        }
        int lives = getLives(player.getUniqueId());
        int min = Math.max(1, getConfig().getInt("withdraw-min-lives", 1));
        if (lives - amount < min) {
            player.sendMessage(msg("withdraw-too-many", Placeholder.unparsed("min", String.valueOf(min))));
            return true;
        }
        applyLives(player, lives - amount);
        giveItem(player, createLifeItem(amount));
        player.sendMessage(msg("withdraw-done",
                Placeholder.unparsed("amount", String.valueOf(amount)),
                Placeholder.unparsed("lives", String.valueOf(lives - amount))));
        return true;
    }

    private boolean handleLives(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player self) {
                self.sendMessage(msg("own-lives",
                        Placeholder.unparsed("lives", String.valueOf(getLives(self.getUniqueId())))));
            } else {
                sender.sendMessage(msg("usage"));
            }
            return true;
        }
        if (!sender.hasPermission("lives.admin")) {
            sender.sendMessage(msg("no-permission"));
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                reloadConfig();
                loadSettings();
                questDefs = YamlConfiguration.loadConfiguration(questsFile);
                loadQuests();
                Bukkit.removeRecipe(reviveKey);
                registerRecipe();
                for (Player player : Bukkit.getOnlinePlayers()) {
                    updateDisplay(player);
                }
                sender.sendMessage(msg("reloaded"));
            }
            case "give" -> {
                Player target = args.length > 1 ? Bukkit.getPlayerExact(args[1])
                        : (sender instanceof Player self ? self : null);
                if (target == null) {
                    sender.sendMessage(msg("unknown-player"));
                    return true;
                }
                int amount = args.length > 2 ? parse(args[2], 1) : 1;
                if (amount < 1) {
                    sender.sendMessage(msg("invalid-number"));
                    return true;
                }
                giveItem(target, createReviveItem(amount));
            }
            case "textures" -> {
                if (!(sender instanceof Player tester)) {
                    sender.sendMessage(msg("players-only"));
                    return true;
                }
                if (textureOverride.remove(tester.getUniqueId())) {
                    tester.sendMessage(Component.text("Textured menus: off (testing mode).", NamedTextColor.GRAY));
                } else {
                    textureOverride.add(tester.getUniqueId());
                    tester.sendMessage(Component.text(
                            "Textured menus: ON for you (testing mode). Open /quests to look.", NamedTextColor.GREEN));
                }
            }
            case "revive" -> {
                OfflinePlayer target = args.length > 1 ? findPlayer(args[1]) : null;
                if (target == null) {
                    sender.sendMessage(msg("unknown-player"));
                    return true;
                }
                applyLives(target, reviveLives);
            }
            case "set", "add", "remove" -> {
                OfflinePlayer target = args.length > 1 ? findPlayer(args[1]) : null;
                if (target == null) {
                    sender.sendMessage(msg("unknown-player"));
                    return true;
                }
                int amount = args.length > 2 ? parse(args[2], -1) : -1;
                if (amount < 0) {
                    sender.sendMessage(msg("invalid-number"));
                    return true;
                }
                int current = getLives(target.getUniqueId());
                int result = switch (sub) {
                    case "set" -> amount;
                    case "add" -> current + amount;
                    default -> current - amount;
                };
                applyLives(target, result);
                sender.sendMessage(msg("lives-set",
                        Placeholder.unparsed("player", String.valueOf(target.getName())),
                        Placeholder.unparsed("lives", String.valueOf(Math.max(0, Math.min(result, maxLives))))));
            }
            default -> sender.sendMessage(msg("usage"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (!sender.hasPermission("lives.admin")) {
            return List.of();
        }
        if (name.equals("lives")) {
            if (args.length == 1) {
                return startsWith(List.of("set", "add", "remove", "revive", "give", "reload", "textures"), args[0]);
            }
            if (args.length == 2 && !args[0].equalsIgnoreCase("reload")) {
                return null; // default: online player names
            }
            return List.of();
        }
        if (name.equals("questadmin")) {
            if (args.length == 1) {
                return startsWith(List.of("assign", "unassign", "delete", "list"), args[0]);
            }
            String sub = args[0].toLowerCase(Locale.ROOT);
            if (args.length == 2 && (sub.equals("assign") || sub.equals("unassign"))) {
                List<String> names = new ArrayList<>();
                names.add("all");
                for (Player player : Bukkit.getOnlinePlayers()) {
                    names.add(player.getName());
                }
                return startsWith(names, args[1]);
            }
            if ((args.length == 2 && sub.equals("delete")) || (args.length == 3
                    && (sub.equals("assign") || sub.equals("unassign")))) {
                return startsWith(new ArrayList<>(quests.keySet()), args[args.length - 1]);
            }
        }
        return List.of();
    }

    // ------------------------------------------------------------------ resource pack (menu textures)

    private boolean textured(Player player) {
        UUID id = player.getUniqueId();
        if (!getConfig().getBoolean("gui.use-textures", true)) {
            return false;
        }
        // assume-pack: for servers that send the pack themselves (server.properties) and require it
        return getConfig().getBoolean("gui.assume-pack", false)
                || packLoaded.contains(id) || textureOverride.contains(id);
    }

    /** The menu title is a single big picture glyph from the resource pack's "lives:menu" font. */
    private Component texturedTitle(char background) {
        return Component.text("\uE001" + background, NamedTextColor.WHITE).font(Key.key("lives", "menu"));
    }

    private void sendPack(Player player) {
        if (!player.isOnline()) {
            return;
        }
        String url = getConfig().getString("resource-pack.url", "");
        if (url == null || url.isBlank()) {
            return;
        }
        try {
            String sha1 = getConfig().getString("resource-pack.sha1", "");
            byte[] hash = null;
            if (sha1 != null && sha1.trim().length() == 40) {
                String clean = sha1.trim();
                hash = new byte[20];
                for (int i = 0; i < 20; i++) {
                    hash[i] = (byte) Integer.parseInt(clean.substring(i * 2, i * 2 + 2), 16);
                }
            }
            boolean force = getConfig().getBoolean("resource-pack.force", false);
            player.setResourcePack(PACK_ID, url.trim(), hash, Component.text("HeartLives menu textures"), force);
        } catch (Exception ex) {
            getLogger().warning("Could not send the resource pack: " + ex.getMessage());
        }
    }

    @EventHandler
    public void onPackStatus(PlayerResourcePackStatusEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        getLogger().info(event.getPlayer().getName() + " resource pack status: " + event.getStatus());
        switch (event.getStatus()) {
            case SUCCESSFULLY_LOADED -> packLoaded.add(id);
            case DECLINED, FAILED_DOWNLOAD -> packLoaded.remove(id);
            default -> {
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private List<String> startsWith(List<String> options, String typed) {
        String lower = typed.toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) {
                matches.add(option);
            }
        }
        return matches;
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online;
        }
        return Bukkit.getOfflinePlayerIfCached(name);
    }

    private int parse(String text, int fallback) {
        try {
            return Integer.parseInt(text.trim());
        } catch (NumberFormatException ex) {
            return fallback;
        }
    }

    private Component msg(String key, TagResolver... resolvers) {
        return MM.deserialize(getConfig().getString("messages." + key, key), resolvers);
    }
}
